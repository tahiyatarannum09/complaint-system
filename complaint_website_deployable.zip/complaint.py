
from flask import Flask, render_template, request, redirect, url_for, session, g, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "complaints.db")

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("FLASK_SECRET", "change_this_secret_in_production")

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    # users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
    )
    """)
    # complaints table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS complaints (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Open',
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    """)
    conn.commit()
    conn.close()

@app.before_request
def load_user():
    g.user = None
    if "user_id" in session:
        conn = get_db()
        g.user = conn.execute("SELECT id, username FROM users WHERE id=?", (session["user_id"],)).fetchone()
        conn.close()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"].strip()
        if not username or not password:
            flash("Please fill both fields.")
            return redirect(url_for("register"))
        conn = get_db()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
                           (username, generate_password_hash(password), datetime.utcnow().isoformat()))
            conn.commit()
            flash("Registration successful. Please login.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Username already taken.")
            return redirect(url_for("register"))
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"].strip()
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            flash("Logged in successfully.")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid credentials.")
            return redirect(url_for("login"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.")
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))
    conn = get_db()
    complaints = conn.execute("SELECT * FROM complaints WHERE user_id=? ORDER BY created_at DESC", (session["user_id"],)).fetchall()
    conn.close()
    return render_template("dashboard.html", complaints=complaints)

@app.route("/complaint/new", methods=["GET","POST"])
def new_complaint():
    if "user_id" not in session:
        return redirect(url_for("login"))
    if request.method == "POST":
        title = request.form["title"].strip()
        description = request.form["description"].strip()
        if not title or not description:
            flash("Please provide title and description.")
            return redirect(url_for("new_complaint"))
        conn = get_db()
        conn.execute("INSERT INTO complaints (user_id, title, description, status, created_at) VALUES (?, ?, ?, ?, ?)",
                     (session["user_id"], title, description, "Open", datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
        flash("Complaint created.")
        return redirect(url_for("dashboard"))
    return render_template("complaint_form.html")

@app.route("/complaint/<int:cid>")
def complaint_detail(cid):
    if "user_id" not in session:
        return redirect(url_for("login"))
    conn = get_db()
    complaint = conn.execute("SELECT * FROM complaints WHERE id=? AND user_id=?", (cid, session["user_id"])).fetchone()
    conn.close()
    if not complaint:
        flash("Complaint not found or access denied.")
        return redirect(url_for("dashboard"))
    return render_template("complaint_detail.html", complaint=complaint)

if __name__ == "__main__":
    init_db()
    print("Database initialized at", DATABASE)
    app.run(debug=True, host="0.0.0.0", port=5000)
